package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import connexion.ConnexionMySQL;

import org.json.JSONObject;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import model.Fond;

@WebServlet("/createFond")
public class CreateFondServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Récupérer les paramètres nécessaires
            double valeurFond = Double.parseDouble(request.getParameter("valeurFond"));
            Timestamp dateFond = Timestamp.valueOf(request.getParameter("dateFond"));
            int idUtilisateur = Integer.parseInt(request.getParameter("idUtilisateur"));
            int statut = Integer.parseInt(request.getParameter("statut"));
            String mailReceiver = request.getParameter("mailreceiver");
            String validationId = request.getParameter("id");
            String validationToken = request.getParameter("token");

            Fond f = new Fond(valeurFond, dateFond, idUtilisateur, statut);

            // Étape 1: Appeler la première API (envoie mail)
            JSONObject apiRequest1 = new JSONObject();
            apiRequest1.put("idu", idUtilisateur);
            apiRequest1.put("mailreceiver", mailReceiver);

            boolean api1Success = callApi("http://localhost:5073/api/VersJava/envoie", "POST", apiRequest1);

            if (api1Success) {
                // Étape 2: Appeler la deuxième API (validation)
                JSONObject apiRequest2 = new JSONObject();
                apiRequest2.put("id", validationId);
                apiRequest2.put("token", validationToken);

                boolean api2Success = callApi("http://localhost:5073/api/VersJava/validationjava?id=" + validationId + "&token=" + validationToken, "GET", null);

                if (api2Success) {
                    // Étape 3: Insérer dans la base de données
                    ConnexionMySQL connexionMySQL = new ConnexionMySQL();
                    try (Connection dbConnection = connexionMySQL.getConnectionMySQL()) {
                        f.insererFond(dbConnection);
                        out.write("{\"success\": true, \"message\": \"Fond inserted successfully.\"}");
                    } catch (SQLException e) {
                        e.printStackTrace();
                        out.write("{\"success\": false, \"message\": \"Database error: " + e.getMessage() + "\"}");
                    }
                } else {
                    out.write("{\"success\": false, \"message\": \"Validation API call failed\"}");
                }
            } else {
                out.write("{\"success\": false, \"message\": \"Email API call failed\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.write("{\"success\": false, \"message\": \"Error: " + e.getMessage() + "\"}");
        }
    }

    // Méthode utilitaire pour appeler une API
    private boolean callApi(String apiUrl, String method, JSONObject payload) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setRequestProperty("Content-Type", "application/json");

        if (payload != null && (method.equalsIgnoreCase("POST") || method.equalsIgnoreCase("PUT"))) {
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes("UTF-8"));
                os.flush();
            }
        }

        int responseCode = conn.getResponseCode();
        if (responseCode == 200) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    responseBuilder.append(line);
                }
                try {
                    JSONObject jsonResponse = new JSONObject(responseBuilder.toString());
                    return "success".equalsIgnoreCase(jsonResponse.optString("status"));
                } catch (JSONException e) {
                    e.printStackTrace();
                    return false; // Retourne false si la réponse JSON est invalide.
                }
            }
        } else {
            return false;
        }
    }
}
