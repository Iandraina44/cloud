using Microsoft.AspNetCore.Mvc;
using connexion.Models;
using user.Models;
using user.Models.DtoClasses; // Importez la classe ConnexionMysql
using MimeKit;
using MailKit.Net.Smtp;
using System;
using email.Models;

namespace check.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VersJava : ControllerBase
    {
        private readonly string emailSender = "mamynyainarazafinjatovo999@gmail.com"; // Email expéditeur
        private readonly string appPassword = "your-app-password"; 
        [HttpPost("envoie")]
        public IActionResult EnvoieMail(int idu,String mailreceiver)
        {
            try
            {
                
                EmailSenderModel.SendEmailVersJava(emailSender, mailreceiver, idu, appPassword);

                return Ok(new
                {
                    status = "success",
                    message = "Mail de validation envoyé avec succès."
                });
            }
            catch (Exception ex)
            {
                // Gestion des erreurs
                return StatusCode(500, new
                {
                    status = "error",
                    error = ex.Message,
                    data = (object)null
                });
            }
        }

        
        [HttpGet("validationjava")]
        public IActionResult validations( string id)
        {
            try
            {
            // Récupération de la connexion via ConnexionMysql
            using (var connection = ConnexionMysql.GetConnexion())
            {
                if (connection == null || connection.State != System.Data.ConnectionState.Open)
                {
                return StatusCode(500, new
                {
                    status = "error",
                    error = "Impossible de se connecter à la base de données.",
                    data = (object)null
                });
                }
                return Ok(new
                {
                status = "success",
                error = (string)null,
                data = new
                {
                    message = "success"
                }
                });
            }
            }
            catch (Exception ex)
            {
            return StatusCode(500, new
            {
                status = "error",
                error = ex.Message,
                data = (object)null
            });
            }
        }

    


    }
}
